﻿#!/usr/bin/python
# -*- coding: latin-1 -*-

"""
"""

import os, sys, time, math

if __name__ == '__main__':
	print "Hola, mundo!"
	print "Salut, monde!"
	print "Orbis, te saluto!"